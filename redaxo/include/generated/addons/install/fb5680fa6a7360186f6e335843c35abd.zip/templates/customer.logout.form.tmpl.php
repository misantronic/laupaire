			<form action="" method="post" name="ss-form-logout" class="ss-form ss-form-logout">
            	<input type="hidden" name="SSForm[<?=$FORM_ID?>][action]" value="<?=$action?>" />
                <p class="ss-submit">
                    <label for="ss-user"><?=$label_customer?></label>
                    <input id="ss-submit" name="SSForm[<?=$FORM_ID?>][submit]" type="submit" class="ss-submit" value="<?=$label_submit?>" />
                </p>
			</form>