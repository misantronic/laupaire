<?php
$REX['ADDON']['install']['square_shop'] = false;

