<?php

echo rex_square_shop_utils::getHtmlFromMDFile('QUICKSTART.md');