<?php

echo rex_square_shop_utils::getHtmlFromMDFile('CHANGELOG.md');

