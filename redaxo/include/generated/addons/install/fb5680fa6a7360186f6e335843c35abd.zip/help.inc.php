<?php echo $I18N->msg('square_shop_addon_help'); ?>
<br />
