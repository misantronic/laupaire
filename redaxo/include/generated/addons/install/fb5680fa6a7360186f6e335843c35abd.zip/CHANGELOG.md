Changelog
=====================

### Version 0.9.0 - 15. Dezember 2014

* Frontend Implementierung in der Alpha-Version

### Version 0.5.0 - 31. Oktober 2014

* Backend Implementierung in der Alpha-Version

