<?php

$REX['ADDON']['update']['square_shop'] = 1;
